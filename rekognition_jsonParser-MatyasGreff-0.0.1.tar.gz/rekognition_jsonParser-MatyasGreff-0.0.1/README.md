# rekognition_jsonParser Package

This is rekognition_jsonParser package
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.